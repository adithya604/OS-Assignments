#include <stdio.h>

void test_hello(void)
{
	printf("\n*******************************************\n\n");
	printf("Hello User!!!\nWelcome to Pintos\n\n");
	printf("*******************************************\n\n");
}
