#ifndef SRC_THREADS_HELLO_H_
#define SRC_THREADS_HELLO_H_

void test_hello(void);

#endif /* SRC_THREADS_HELLO_H_ */
