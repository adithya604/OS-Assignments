1. External commands like ls are implemented
2. Shell builtins (cd, pwd, export) are implemented but setting enviromental variable without export ie like 'x=2' instead of 'export x=2'
3. Printing environmental variables and text using echo are implemented
4. Background and foreground functionality is not implemented
5. multiple piping is implemented
6. IO Redirection and IO Redirection along with piping is implemented
7. History is implemented and bang operator  implemented 
8. Interrupt Signal CTRL+C is handled but others are not handled
