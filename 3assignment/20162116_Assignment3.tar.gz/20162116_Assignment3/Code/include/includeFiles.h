#include <stdio.h>
#include <cstdio>
#include <string.h>
#include <stdlib.h>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <fstream>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <vector>
#include <map>
#include <algorithm>
#include <signal.h>
#include <iomanip>

using namespace std;



	//	char *cstr = new char [command.length()+1];
  	//	strcpy (cstr, command.c_str());

  	//	char *p = strtok (cstr," \t");
  		//cout<<p<<endl;
  	//	if(strcmp(p,"exit") == 0)
  	//		exit(0);
  		//cout<<command<<endl;


		//cout<<parameters.at(0);